# IPTV M3U Generator

## Overview

This is a Flask-based web application that generates M3U playlist files from IPTV portal servers. The application allows users to input portal URLs and MAC addresses to fetch channel data and generate downloadable M3U files organized by genre or as a complete playlist.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Bootstrap 5 with custom CSS
- **Layout**: Responsive design with RTL (right-to-left) support for Arabic interface
- **UI Components**: Cards, progress bars, alerts, and forms
- **JavaScript**: Used for real-time status updates and form interactions

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Structure**: Modular design with separate fetching logic
- **Session Management**: Flask sessions with configurable secret key
- **Middleware**: ProxyFix for handling proxy headers

### Key Components

1. **Web Application (`app.py`)**
   - Main Flask application with routes for home page, download initiation, and status monitoring
   - Global state management for tracking download progress
   - Error handling and user feedback through Flask flash messages

2. **IPTV Fetcher (`iptv_fetcher.py`)**
   - Core logic for communicating with IPTV portal APIs
   - Channel data retrieval and M3U file generation
   - Genre-based organization and file sanitization

3. **Templates**
   - `index.html`: Main interface for inputting portal credentials and selecting download options
   - `status.html`: Real-time progress tracking page with AJAX updates

## Data Flow

1. User inputs portal URL and MAC address through web interface
2. Application validates input and initiates background download process
3. IPTVFetcher communicates with portal API to retrieve channel genres
4. For each genre, the fetcher retrieves channel lists and generates M3U files
5. Progress updates are stored in global state and displayed to user in real-time
6. Completed files are made available for download

## External Dependencies

### Python Packages
- **Flask**: Web framework for handling HTTP requests and responses
- **Requests**: HTTP library for communicating with IPTV portal APIs
- **Werkzeug**: WSGI utilities including ProxyFix middleware

### Frontend Libraries
- **Bootstrap 5**: CSS framework for responsive UI components
- **Font Awesome 6**: Icon library for visual elements

### IPTV Portal Integration
- Communicates with external IPTV portal servers using their specific API endpoints
- Requires MAC address authentication for accessing channel data
- Handles JSON responses from portal APIs

## Deployment Strategy

### Environment Configuration
- Uses environment variables for sensitive configuration (SESSION_SECRET)
- Fallback values provided for development environments
- Configurable logging levels for debugging

### File Structure
- Static files served through Flask's static file handling
- Generated M3U files stored in local "output" directory
- Template rendering through Jinja2 engine

### Production Considerations
- ProxyFix middleware configured for deployment behind reverse proxies
- Session security through configurable secret keys
- Request timeout handling for external API calls
- Error logging and user-friendly error messages

The application is designed to be self-contained with minimal external dependencies, making it suitable for deployment on various platforms including Replit.

## Recent Changes: Latest modifications with dates

### 2025-07-19: Major Performance Optimizations and UI Redesign
- **Parallel Processing Implementation**: Added concurrent.futures ThreadPoolExecutor for simultaneous genre processing
- **Multi-threaded Channel Fetching**: Implemented parallel page fetching within each genre using up to 8 worker threads
- **Connection Optimization**: Enhanced HTTP sessions with keep-alive connections, connection pooling, and gzip compression
- **Timeout Reduction**: Reduced request timeout from 20s to 8s for faster failure detection
- **Thread Pool Scaling**: Increased max workers from 5 to 30 for handling large channel lists
- **Session Pooling**: Implemented connection pooling with 15 connections per pool and 30 max pool size
- **Expected Performance**: Target completion time reduced from several minutes to under 10 seconds for 37,000+ channels

### 2025-07-19: Modern UI Redesign
- **Complete UI Overhaul**: Redesigned interface to match modern mobile app aesthetics based on user's provided reference image
- **Clean Card Layout**: Replaced complex forms with clean, card-based design using white backgrounds and subtle shadows
- **Simplified Navigation**: Streamlined interface with clear sections for connection info and download options
- **Interactive Elements**: Added connection test button with loading states and visual feedback
- **Enhanced Radio Buttons**: Improved download option selection with clickable cards and visual highlighting
- **Modern Typography**: Updated fonts and spacing for better readability and professional appearance
- **Responsive Design**: Optimized for mobile and desktop viewing with proper scaling
- **Arabic RTL Support**: Maintained right-to-left layout support while modernizing the design