import requests
import os
import re
import logging
import math # لاستخدامه إذا عرفنا إجمالي العناصر وحجم الصفحة

# تكوين التسجيل (Logging)
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# معلومات الاتصال (تأكد من صحتها)
PORTAL_URL = "http://drk.yasar.tv"
MAC_ADDRESS = "00:1A:79:57:99:81" 

# تحديد مجلد الحفظ
SAVE_FOLDER = "output"
os.makedirs(SAVE_FOLDER, exist_ok=True)

# --- (وظائف sanitize_filename و fetch_json و get_genres تبقى كما هي من المثال السابق) ---
def sanitize_filename(name):
    """ينظف اسم الملف من الأحرف غير الصالحة."""
    return re.sub(r'[\\/*?:"<>|]', "_", name)

def fetch_json(url, session):
    """يجلب البيانات بتنسيق JSON من عنوان URL المحدد."""
    try:
        logging.debug(f"Fetching URL: {url}") 
        response = session.get(url, timeout=20) 
        response.raise_for_status() 
        
        content_type = response.headers.get('Content-Type', '')
        if 'application/json' not in content_type and 'text/javascript' not in content_type:
             logging.warning(f"⚠️ استجابة غير متوقعة ليست JSON من {url}. المحتوى: {response.text[:200]}...") 
             return None
             
        json_data = response.json()
        # قم بإلغاء التعليق التالي فقط عند الحاجة لفحص استجابة معينة لتحديد تفاصيل ترقيم الصفحات
        # logging.debug(f"Raw JSON response from {url}: {json_data}") 
        return json_data
        
    except requests.exceptions.Timeout:
        logging.error(f"❌ خطأ: انتهت مهلة الاتصال بـ {url}")
        return None
    except requests.exceptions.RequestException as e:
        logging.error(f"❌ خطأ في الاتصال بـ {url}: {e}")
        return None
    except ValueError: # Includes JSONDecodeError
        logging.error(f"⚠️ فشل في تحليل JSON من {url}. محتوى الاستجابة: {response.text[:200]}...")
        return None

def get_genres(session):
    """يجلب قائمة التصنيفات المتاحة."""
    url = f"{PORTAL_URL}/portal.php?type=itv&action=get_genres&mac={MAC_ADDRESS}&JsHttpRequest=1-xml"
    data = fetch_json(url, session)
    
    if data and "js" in data and isinstance(data["js"], list):
        genres = data["js"]
        logging.info(f"🔍 تم العثور على {len(genres)} تصنيف.")
        return genres
    else:
        logging.error("❌ فشل في جلب التصنيفات أو أن التنسيق غير متوقع.")
        logging.debug(f"Data received for genres: {data}")
        return []
# --- نهاية الوظائف التي لم تتغير ---

def get_channels_by_genre(genre_id, genre_name, session):
    """
    يجلب *جميع* القنوات لتصنيف محدد، مع التعامل مع ترقيم الصفحات (Pagination).
    """
    all_channels_in_genre = []
    page = 1
    max_pages_to_try = 20 # حد أمان لمنع الحلقات اللانهائية

    logging.info(f"  Fetching channels for genre '{genre_name}' (ID: {genre_id}) - starting page {page}...")

    while page <= max_pages_to_try:
        # افترض أن معامل الصفحة هو 'p'. قد تحتاج لتغييره إلى 'page' أو غيره.
        page_param = f"&p={page}" 
        
        # بناء URL مع معامل الصفحة
        url = (f"{PORTAL_URL}/portal.php?type=itv&action=get_ordered_list"
               f"&genre={genre_id}"
               f"{page_param}" # إضافة معامل الصفحة هنا
               f"&mac={MAC_ADDRESS}&JsHttpRequest=1-xml")

        data = fetch_json(url, session)

        # تحقق من بنية الاستجابة
        if data and "js" in data and isinstance(data["js"], dict) and "data" in data["js"] and isinstance(data["js"]["data"], list):
            channels_on_this_page = data["js"]["data"]
            
            if channels_on_this_page:
                logging.info(f"    Page {page}: Found {len(channels_on_this_page)} channels.")
                all_channels_in_genre.extend(channels_on_this_page)
                
                # --- منطق تحديد هل هذه هي الصفحة الأخيرة ---
                # الخيار 1: إذا كانت الاستجابة تحتوي على معلومات الصفحات (مثالي)
                # total_items = data["js"].get("total_items") 
                # items_per_page = data["js"].get("max_page_items")
                # if total_items is not None and items_per_page is not None and items_per_page > 0:
                #     total_pages = math.ceil(total_items / items_per_page)
                #     if page >= total_pages:
                #         logging.info(f"    Reached calculated last page ({page}/{total_pages}).")
                #         break # انتهينا

                # الخيار 2: التوقف إذا كان عدد القنوات المستلمة أقل من المتوقع (يحتاج لتخمين حجم الصفحة)
                # assumed_page_size = 50 # مثال: افترض أن الصفحة تحوي 50 كحد أقصى
                # if len(channels_on_this_page) < assumed_page_size:
                #      logging.info(f"    Received fewer channels ({len(channels_on_this_page)}) than assumed page size ({assumed_page_size}), assuming last page.")
                #      break # نفترض أنها الصفحة الأخيرة

                # الخيار 3 (المستخدم هنا): التوقف عندما تُرجع الصفحة التالية قائمة فارغة (الأبسط إذا لم تتوفر معلومات)
                # لا يوجد break هنا، نعتمد على الشرط التالي

                page += 1 # انتقل إلى الصفحة التالية
            else:
                # توقف إذا كانت قائمة القنوات فارغة، مما يعني أننا تجاوزنا الصفحة الأخيرة
                logging.info(f"    Page {page}: Received empty channel list. Assuming end of pages for this genre.")
                break 
        else:
            # خطأ في جلب الصفحة أو تنسيق غير متوقع
            logging.warning(f"⚠️ Failed to fetch or parse page {page} for genre ID {genre_id}. Stopping pagination for this genre.")
            logging.debug(f"Data received for page {page}, genre {genre_id}: {data}")
            break # توقف عن محاولة جلب المزيد من الصفحات لهذا التصنيف

    if page > max_pages_to_try:
         logging.warning(f"⚠️ Reached maximum page limit ({max_pages_to_try}) for genre '{genre_name}'. Pagination might be incomplete.")

    logging.info(f"  -> Finished fetching for genre '{genre_name}'. Total channels found: {len(all_channels_in_genre)}")
    return all_channels_in_genre


def save_m3u_file(filename_base, channels_list):
    """يحفظ قائمة القنوات المنسقة في ملف M3U."""
    if not channels_list:
        logging.warning(f"⚠️ لا توجد قنوات لحفظها في الملف {filename_base}.m3u")
        return

    clean_filename = sanitize_filename(filename_base)
    filepath = os.path.join(SAVE_FOLDER, f"{clean_filename}.m3u")
    
    try:
        # نستخدم 'a' للإضافة بدلاً من 'w' للكتابة فوق الملف في كل مرة (إذا كنت تريد ملف واحد لكل نوع)
        # ولكن بما أننا نجلب كل القنوات للنوع مرة واحدة، 'w' أفضل هنا
        with open(filepath, "w", encoding="utf-8") as file: 
            file.write("#EXTM3U\n")
            for channel_entry in channels_list:
                 file.write(channel_entry + "\n") 
        
        num_channels_saved = len(channels_list) // 2 # كل قناة تأخذ سطرين
        logging.info(f"✅ تم إنشاء/تحديث الملف بنجاح: {filepath} ({num_channels_saved} قناة)")
    except IOError as e: 
        logging.error(f"❌ خطأ في كتابة الملف {filepath}: {e}")


def main():
    """الوظيفة الرئيسية لتشغيل السكربت."""
    logging.info("🚀 بدء عملية جلب القنوات (ملف منفصل لكل تصنيف)...")

    with requests.Session() as session:
        session.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'})

        genres = get_genres(session)
        if not genres:
            logging.error("❌ فشل في جلب قائمة التصنيفات. لا يمكن المتابعة.")
            return

        total_channels_overall = 0

        for genre in genres:
            genre_id = genre.get("id", "unknown_id")
            genre_name = genre.get("title", "Unknown Genre")
            
            # استدعاء الوظيفة المعدلة التي تتعامل مع ترقيم الصفحات
            channels_data_full = get_channels_by_genre(genre_id, genre_name, session)
            
            # قائمة لتنسيق القنوات لهذا التصنيف المحدد
            formatted_channels_for_genre = []

            if channels_data_full:
                 # تنسيق القنوات التي تم العثور عليها لهذا التصنيف
                for channel in channels_data_full:
                    channel_name = channel.get('name', 'Unknown Channel')
                    channel_id = channel.get('id') 
                    if channel_id:
                        stream_url = f"{PORTAL_URL}/play/live.php?mac={MAC_ADDRESS}&stream={channel_id}&extension=ts"
                        # يمكنك تضمين group-title هنا أيضاً إذا أردت، أو تركه بسيطاً
                        extinf_line = f"#EXTINF:-1,{channel_name}" 
                        # أو: extinf_line = f"#EXTINF:-1 group-title=\"{genre_name}\",{channel_name}"
                        
                        formatted_channels_for_genre.append(extinf_line)
                        formatted_channels_for_genre.append(stream_url)
                    else:
                         logging.warning(f"⚠️ تم تخطي قناة بدون معرف (ID) في التصنيف '{genre_name}': {channel_name}")
                
                # حفظ ملف M3U لهذا التصنيف المحدد
                save_m3u_file(genre_name, formatted_channels_for_genre)
                total_channels_overall += len(formatted_channels_for_genre) // 2
            else:
                 # لا توجد قنوات لهذا التصنيف أو حدث خطأ أثناء الجلب
                 logging.info(f"ℹ️ No channels found or saved for genre: '{genre_name}'")


    logging.info(f"🔢 العدد الإجمالي للقنوات التي تم العثور عليها عبر جميع التصنيفات: {total_channels_overall}")
    logging.info("🏁 انتهت عملية جلب القنوات.")


if __name__ == "__main__":
    main()
