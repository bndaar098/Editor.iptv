import requests
import os
import re
import logging
import math
import time
import concurrent.futures
import threading
from queue import Queue

class IPTVFetcher:
    def __init__(self, portal_url, mac_address):
        self.portal_url = portal_url.rstrip('/')
        self.mac_address = mac_address
        self.save_folder = "output"
        os.makedirs(self.save_folder, exist_ok=True)
        self.max_workers = 30  # زيادة عدد الخيوط المتوازية
        self.request_timeout = 8   # تقليل وقت انتظار الطلبات أكثر
        self.max_pages_per_genre = 20  # حد أقصى للصفحات لكل تصنيف
        
    def sanitize_filename(self, name):
        """Clean filename from invalid characters"""
        return re.sub(r'[\\/*?:"<>|]', "_", name)

    def fetch_json(self, url, session):
        """Fetch JSON data from specified URL"""
        try:
            logging.debug(f"Fetching URL: {url}")
            response = session.get(url, timeout=self.request_timeout)
            response.raise_for_status()
            
            content_type = response.headers.get('Content-Type', '')
            if 'application/json' not in content_type and 'text/javascript' not in content_type:
                logging.warning(f"⚠️ Unexpected non-JSON response from {url}. Content: {response.text[:200]}...")
                return None
                
            json_data = response.json()
            return json_data
            
        except requests.exceptions.Timeout:
            logging.error(f"❌ Connection timeout to {url}")
            return None
        except requests.exceptions.RequestException as e:
            logging.error(f"❌ Connection error to {url}: {e}")
            return None
        except ValueError:
            logging.error(f"⚠️ Failed to parse JSON from {url}. Response content: {response.text[:200]}...")
            return None

    def get_genres(self, session):
        """Fetch available genres list"""
        url = f"{self.portal_url}/portal.php?type=itv&action=get_genres&mac={self.mac_address}&JsHttpRequest=1-xml"
        data = self.fetch_json(url, session)
        
        if data and "js" in data and isinstance(data["js"], list):
            genres = data["js"]
            logging.info(f"🔍 Found {len(genres)} genres.")
            return genres
        else:
            logging.error("❌ Failed to fetch genres or unexpected format.")
            logging.debug(f"Data received for genres: {data}")
            return []

    def fetch_page_data(self, genre_id, page, session):
        """جلب صفحة واحدة من القنوات بشكل متوازي"""
        page_param = f"&p={page}"
        url = (f"{self.portal_url}/portal.php?type=itv&action=get_ordered_list"
               f"&genre={genre_id}"
               f"{page_param}"
               f"&mac={self.mac_address}&JsHttpRequest=1-xml")
        
        data = self.fetch_json(url, session)
        if data and "js" in data and isinstance(data["js"], dict) and "data" in data["js"]:
            return data["js"]["data"]
        return []

    def get_channels_by_genre_fast(self, genre_id, genre_name, session):
        """جلب القنوات بشكل أسرع باستخدام التحميل المتوازي"""
        all_channels = []
        
        # جلب الصفحة الأولى لمعرفة عدد الصفحات
        first_page_data = self.fetch_page_data(genre_id, 1, session)
        if not first_page_data:
            return []
        
        all_channels.extend(first_page_data)
        
        # تجربة جلب صفحات متعددة متوازية (نحدد عدد الصفحات بناءً على حجم الصفحة الأولى)
        max_concurrent_pages = min(self.max_pages_per_genre, 15)
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
            # إنشاء جلسات منفصلة لكل خيط مع تحسينات الاتصال
            sessions = [requests.Session() for _ in range(8)]
            for s in sessions:
                s.headers.update({
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Connection': 'keep-alive',
                    'Accept-Encoding': 'gzip, deflate'
                })
                # تحسين إعدادات الجلسة
                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=10,
                    pool_maxsize=20,
                    max_retries=1
                )
                s.mount('http://', adapter)
                s.mount('https://', adapter)
            
            # جلب الصفحات 2-10 بشكل متوازي
            future_to_page = {}
            for page in range(2, max_concurrent_pages + 1):
                session_idx = (page - 2) % len(sessions)
                future = executor.submit(self.fetch_page_data, genre_id, page, sessions[session_idx])
                future_to_page[future] = page
            
            # جمع النتائج
            for future in concurrent.futures.as_completed(future_to_page):
                page = future_to_page[future]
                try:
                    page_channels = future.result()
                    if page_channels:
                        all_channels.extend(page_channels)
                    else:
                        # إذا كانت الصفحة فارغة، لا حاجة لجلب المزيد
                        break
                except Exception as e:
                    logging.warning(f"خطأ في جلب الصفحة {page} للتصنيف {genre_name}: {e}")
        
        logging.info(f"جُلب {len(all_channels)} قناة للتصنيف '{genre_name}' بسرعة")
        return all_channels

    def get_channels_by_genre(self, genre_id, genre_name, session):
        """Fetch all channels for a specific genre with fast parallel loading"""
        return self.get_channels_by_genre_fast(genre_id, genre_name, session)

    def save_m3u_file(self, filename_base, channels_list):
        """Save formatted channels list to M3U file"""
        if not channels_list:
            logging.warning(f"⚠️ No channels to save in file {filename_base}.m3u")
            return None

        clean_filename = self.sanitize_filename(filename_base)
        filepath = os.path.join(self.save_folder, f"{clean_filename}.m3u")
        
        try:
            with open(filepath, "w", encoding="utf-8") as file:
                file.write("#EXTM3U\n")
                for channel_entry in channels_list:
                    file.write(channel_entry + "\n")
            
            num_channels_saved = len(channels_list) // 2
            logging.info(f"✅ File created/updated successfully: {filepath} ({num_channels_saved} channels)")
            return os.path.basename(filepath)
        except IOError as e:
            logging.error(f"❌ Error writing file {filepath}: {e}")
            return None

    def save_combined_m3u_file(self, all_channels_by_genre):
        """Save all channels from all genres in one M3U file with group-title organization"""
        if not all_channels_by_genre:
            logging.warning("⚠️ No channels to save in combined file")
            return None

        filepath = os.path.join(self.save_folder, "All_IPTV_Channels.m3u")
        total_channels = 0
        
        try:
            with open(filepath, "w", encoding="utf-8") as file:
                file.write("#EXTM3U\n")
                file.write(f"# Generated by IPTV Fetcher - {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                file.write("# All channels organized by genre\n\n")
                
                for genre_name, channels_list in all_channels_by_genre.items():
                    if channels_list:
                        file.write(f"# === {genre_name} ===\n")
                        for i in range(0, len(channels_list), 2):
                            if i + 1 < len(channels_list):
                                # Modify EXTINF line to include group-title
                                extinf_line = channels_list[i]
                                if extinf_line.startswith("#EXTINF:"):
                                    # Add group-title to the EXTINF line
                                    extinf_line = extinf_line.replace("#EXTINF:-1,", f"#EXTINF:-1 group-title=\"{genre_name}\",")
                                file.write(extinf_line + "\n")
                                file.write(channels_list[i + 1] + "\n")
                                total_channels += 1
                        file.write("\n")
            
            logging.info(f"✅ Combined file created successfully: {filepath} ({total_channels} channels from {len(all_channels_by_genre)} genres)")
            return os.path.basename(filepath)
        except IOError as e:
            logging.error(f"❌ Error writing combined file {filepath}: {e}")
            return None

    def process_genre(self, genre, session, progress_callback=None, current_idx=0, total_genres=0):
        """معالجة تصنيف واحد بشكل متوازي"""
        genre_id = genre.get("id", "unknown_id")
        genre_name = genre.get("title", "Unknown Genre")
        
        if progress_callback:
            progress_callback(current_idx, total_genres, genre_name)
        
        channels_data_full = self.get_channels_by_genre(genre_id, genre_name, session)
        formatted_channels_for_genre = []

        if channels_data_full:
            for channel in channels_data_full:
                channel_name = channel.get('name', 'Unknown Channel')
                channel_id = channel.get('id')
                if channel_id:
                    stream_url = f"{self.portal_url}/play/live.php?mac={self.mac_address}&stream={channel_id}&extension=ts"
                    extinf_line = f"#EXTINF:-1,{channel_name}"
                    
                    formatted_channels_for_genre.append(extinf_line)
                    formatted_channels_for_genre.append(stream_url)
        
        return genre_name, formatted_channels_for_genre

    def download_separate_m3u(self, progress_callback=None):
        """Download separate M3U files for each genre with parallel processing"""
        logging.info("🚀 Starting fast channel fetching process (separate files)...")
        
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })

        genres = self.get_genres(session)
        if not genres:
            raise Exception("Failed to fetch genres list. Cannot continue.")

        total_genres = len(genres)
        completed_files = []
        total_channels_overall = 0
        
        # معالجة التصنيفات بشكل متوازي
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # إنشاء جلسات محسنة لكل خيط  
            sessions = []
            for i in range(self.max_workers):
                s = requests.Session()
                s.headers.update({
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Connection': 'keep-alive',
                    'Accept-Encoding': 'gzip, deflate'
                })
                # تحسين أداء الجلسة
                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=15,
                    pool_maxsize=30,
                    max_retries=1
                )
                s.mount('http://', adapter)
                s.mount('https://', adapter)
                sessions.append(s)
            
            # إرسال مهام التصنيفات للمعالجة المتوازية
            future_to_genre = {}
            for idx, genre in enumerate(genres):
                session_idx = idx % len(sessions)
                future = executor.submit(
                    self.process_genre, 
                    genre, 
                    sessions[session_idx], 
                    progress_callback, 
                    idx, 
                    total_genres
                )
                future_to_genre[future] = genre
            
            # جمع النتائج
            for future in concurrent.futures.as_completed(future_to_genre):
                try:
                    genre_name, formatted_channels = future.result()
                    
                    if formatted_channels:
                        filename = self.save_m3u_file(genre_name, formatted_channels)
                        if filename:
                            completed_files.append(filename)
                        total_channels_overall += len(formatted_channels) // 2
                    else:
                        logging.info(f"ℹ️ No channels found for genre: '{genre_name}'")
                        
                except Exception as e:
                    logging.error(f"خطأ في معالجة تصنيف: {e}")

        logging.info(f"🔢 Total channels found: {total_channels_overall}")
        logging.info("🏁 Fast fetching completed!")
        
        return completed_files

    def download_combined_m3u(self, progress_callback=None):
        """Download all channels in one combined M3U file with parallel processing"""
        logging.info("🚀 Starting fast channel fetching process (combined file)...")
        
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        })

        genres = self.get_genres(session)
        if not genres:
            raise Exception("Failed to fetch genres list. Cannot continue.")

        total_genres = len(genres)
        all_channels_by_genre = {}
        total_channels_overall = 0
        
        # معالجة جميع التصنيفات بشكل متوازي
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # إنشاء جلسات محسنة لكل خيط
            sessions = []
            for i in range(self.max_workers):
                s = requests.Session()
                s.headers.update({
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Connection': 'keep-alive',
                    'Accept-Encoding': 'gzip, deflate'
                })
                # تحسين أداء الجلسة
                adapter = requests.adapters.HTTPAdapter(
                    pool_connections=15,
                    pool_maxsize=30,
                    max_retries=1
                )
                s.mount('http://', adapter)
                s.mount('https://', adapter)
                sessions.append(s)
            
            # إرسال جميع التصنيفات للمعالجة المتوازية
            future_to_genre = {}
            for idx, genre in enumerate(genres):
                session_idx = idx % len(sessions)
                future = executor.submit(
                    self.process_genre, 
                    genre, 
                    sessions[session_idx], 
                    progress_callback, 
                    idx, 
                    total_genres
                )
                future_to_genre[future] = genre
            
            # جمع النتائج من جميع التصنيفات
            for future in concurrent.futures.as_completed(future_to_genre):
                try:
                    genre_name, formatted_channels = future.result()
                    
                    if formatted_channels:
                        all_channels_by_genre[genre_name] = formatted_channels
                        total_channels_overall += len(formatted_channels) // 2
                    else:
                        logging.info(f"ℹ️ No channels found for genre: '{genre_name}'")
                        
                except Exception as e:
                    logging.error(f"خطأ في معالجة تصنيف: {e}")

        # حفظ الملف الموحد
        filename = self.save_combined_m3u_file(all_channels_by_genre)
        
        logging.info(f"🔢 Total channels found: {total_channels_overall}")
        logging.info("🏁 Fast combined file creation completed!")
        
        return filename
