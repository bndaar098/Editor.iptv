import os
import logging
from flask import Flask, render_template, request, jsonify, send_file, flash, redirect, url_for
from werkzeug.middleware.proxy_fix import ProxyFix
import threading
import time
from iptv_fetcher import IPTVFetcher

# Configure logging
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback_secret_key_for_development")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Global variables to track download progress
download_status = {
    'is_running': False,
    'progress': 0,
    'current_genre': '',
    'total_channels': 0,
    'error': None,
    'completed_files': []
}

@app.route('/')
def index():
    """Main page with download options"""
    return render_template('index.html')

@app.route('/download', methods=['POST'])
def download():
    """Handle download requests"""
    global download_status
    
    if download_status['is_running']:
        flash('تحميل آخر قيد التشغيل. يرجى الانتظار.', 'warning')
        return redirect(url_for('index'))
    
    download_type = request.form.get('download_type')
    portal_url = request.form.get('portal_url', '').strip()
    mac_address = request.form.get('mac_address', '').strip()
    
    if not portal_url or not mac_address:
        flash('يرجى إدخال رابط البوابة وعنوان MAC', 'error')
        return redirect(url_for('index'))
    
    # Reset status
    download_status = {
        'is_running': True,
        'progress': 0,
        'current_genre': '',
        'total_channels': 0,
        'error': None,
        'completed_files': []
    }
    
    # Start download in background thread
    thread = threading.Thread(target=perform_download, args=(download_type, portal_url, mac_address))
    thread.daemon = True
    thread.start()
    
    flash('بدء عملية التحميل...', 'info')
    return redirect(url_for('status'))

@app.route('/status')
def status():
    """Download status page"""
    return render_template('status.html', status=download_status)

@app.route('/api/status')
def api_status():
    """API endpoint for status updates"""
    return jsonify(download_status)

@app.route('/download-file/<filename>')
def download_file(filename):
    """Download generated M3U files"""
    try:
        file_path = os.path.join('output', filename)
        if os.path.exists(file_path):
            return send_file(file_path, as_attachment=True, download_name=filename)
        else:
            flash('الملف غير موجود', 'error')
            return redirect(url_for('index'))
    except Exception as e:
        logging.error(f"Error downloading file {filename}: {e}")
        flash('خطأ في تحميل الملف', 'error')
        return redirect(url_for('index'))

def update_progress(current, total, genre_name=''):
    """Update download progress"""
    global download_status
    download_status['progress'] = int((current / total) * 100) if total > 0 else 0
    download_status['current_genre'] = genre_name

def perform_download(download_type, portal_url, mac_address):
    """Perform the actual download in background"""
    global download_status
    
    try:
        fetcher = IPTVFetcher(portal_url, mac_address)
        
        if download_type == 'combined':
            # Download all channels in one file
            filename = fetcher.download_combined_m3u(progress_callback=update_progress)
            if filename:
                download_status['completed_files'] = [filename]
                download_status['progress'] = 100
        else:
            # Download separate files per genre
            filenames = fetcher.download_separate_m3u(progress_callback=update_progress)
            download_status['completed_files'] = filenames
            download_status['progress'] = 100
            
    except Exception as e:
        logging.error(f"Download error: {e}")
        download_status['error'] = str(e)
    finally:
        download_status['is_running'] = False

if __name__ == '__main__':
    # Ensure output directory exists
    os.makedirs('output', exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)
